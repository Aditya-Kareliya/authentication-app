import React, { useState } from 'react'
import { Link } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const handleLogin = (e) => {
        e.preventDefault();
        alert('Logged in Succefull');
    };
    return (
        <>
            <div className="container mt-5 mb-5 p-5 border ">
                <h2 className='text-center'>Login</h2>
                <form onSubmit={handleLogin} className='row g-3 p-5'>
                    <div className="col-md-6">
                        <label htmlFor="email" className="form-label">
                            Email
                        </label>
                        <input
                            type="email"
                            className="form-control"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-md-6">
                        <label htmlFor="password" className="form-label">
                            Password
                        </label>
                        <input
                            type="password"
                            className="form-control"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    <div style={{ alignItems: 'center', justifyContent: 'center', display: 'flex' }}>
                        <button type="submit" className="btn btn-primary  col-md-3" >
                            Login
                        </button>
                    </div>
                    <div className='text-center mt-3'>
                        Don't Have an Account ? <Link to="/signup">Signup</Link>
                    </div>
                </form>
            </div>
        </>
    )
}

export default Login
import React from 'react'

const Footer = () => {
    return (
        <>
            <div class="card text-center">
                <div class="card-header">
                Chaintech Network
                </div>
                <div class="card-body">
                    <h5 class="card-title">Authentication Application</h5>
                    <p class="card-text">If it's smart, it's vulnerable</p>
                </div>
                <div class="card-footer text-body-secondary">
                    @Aditya Kareliya
                </div>
            </div>
        </>
    )
}

export default Footer
import React from 'react'
import Layout from './Layout/Layout'

const Home = () => {
    return (
        <>
            <h1 className='text-center mt-5 pt-5 text-primary'>
                Welcome
            </h1>
            <h4 className='text-center mb-5 pb-5'>
                CHAINTECH NETWORK
            </h4>
        </>
    )
}

export default Home
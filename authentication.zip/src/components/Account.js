import React, { useState } from 'react'

const Account = () => {
    const [userInfo, setUserInfo] = useState({
        name: "Chaintech Network",
        email: "chaintech@network.com",
    });

    const handleChange = (e) => {
        setUserInfo({ ...userInfo, [e.target.name]: e.target.value });
    };

    const handleSave = (e) => {
        e.preventDefault();
        alert("Account information updated");
    };
    return (
        <>
            <div className="container mt-5 mb-5 p-5 border">
                <h2 className='text-center'>Account Information</h2>
                <form onSubmit={handleSave} className='row g-3 p-5'>
                    <div className="col-md-6">
                        <label htmlFor="name" className="form-label">
                            Name
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            id="name"
                            name="name"
                            value={userInfo.name}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="col-md-6">
                        <label htmlFor="email" className="form-label">
                            Email
                        </label>
                        <input
                            type="email"
                            className="form-control"
                            id="email"
                            name="email"
                            value={userInfo.email}
                            onChange={handleChange}
                        />
                    </div>
                    <div style={{ alignItems: 'center', justifyContent: 'center', display: 'flex' }}>
                        <button type="submit" className="btn btn-primary  col-md-3" >
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default Account
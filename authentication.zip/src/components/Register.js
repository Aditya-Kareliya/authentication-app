import React, { useState } from 'react'
import { Link } from 'react-router-dom';

const Register = () => {
    const [user, setUser] = useState({ name: "", email: "", password: "" });

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleRegister = (e) => {
        e.preventDefault();
        alert('User registered');
    };
    return (
        <>
            <div className="container mt-5 mb-5 p-5 border">
                <h2 className='text-center'>Register</h2>
                <form onSubmit={handleRegister} className='row g-3 p-5'>
                    <div className="col-md-6">
                        <label htmlFor="name" className="form-label">
                            Username
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            id="name"
                            name="name"
                            value={user.name}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="col-md-6">
                        <label htmlFor="email" className="form-label">
                            Email
                        </label>
                        <input
                            type="email"
                            className="form-control"
                            id="email"
                            name="email"
                            value={user.email}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="password" className="form-label">
                            Password
                        </label>
                        <input
                            type="password"
                            className="form-control"
                            id="password"
                            name="password"
                            value={user.password}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div style={{ alignItems: 'center', justifyContent: 'center', display: 'flex' }}>
                        <button type="submit" className="btn btn-primary col-md-3">
                            Register
                        </button>
                    </div>
                    <div className='text-center mt-3'>
                        Already Have an Account <Link to="/login">Login</Link>
                    </div>
                </form>
            </div>
        </>
    )
}

export default Register